;(async () => {
  try {
    // Retrieve profile and analysis from context
    const studentProfile = getContext("studentProfile")
    const profileAnalysis = getContext("profileAnalysis")

    if (!studentProfile || !profileAnalysis) {
      throw new Error("Missing profile or analysis context")
    }

    console.log("Generating structured Smart Career Report...")
    // Construct strict-format Smart Career Report prompt for TurboticOpenAI
    const reportPrompt = `You are an expert career counsellor. Using ONLY the information in the provided student profile and AI analysis, generate a highly structured Smart Career Report with the following clearly formatted, titled sections:

1. Strongest Competitive Advantage
   - Clear paragraph summarizing the student's #1 unique or competitive advantage for career success.

2. Matching Opportunities (3)
   For each:
      - Name
      - Why it matches (2-3 lines)
      - Match Confidence Score (%)

3. Resume Summary
   - 5 concise lines suitable for a professional resume profile.

4. Short Statement of Purpose (SOP)
   - Max 150 words, well-crafted & personal.

5. Recruiter Email
   - Max 100 words. A professional short intro for job applications.

6. 5-Step Action Plan
   - 5 clear action points to maximize employability & results.

7. Skill Gap Analysis
   - Missing skills for the top career path.
   - Specific recommendations to close gap.

8. Recommended Certifications or Courses
   - List relevant certifications/courses (with 1-line rationale for each).

Please use bullet points, bolded headings, and professional formatting for clarity.

Student Profile: ${JSON.stringify(studentProfile, null, 2)}

AI Analysis: ${profileAnalysis}`

    const aiResult = await TurboticOpenAI([{ role: "user", content: reportPrompt }], {
      model: "gpt-4.1",
      temperature: 0
    })

    setContext("careerReport", aiResult.content)
    console.log("Smart Career Report generated and saved in context.")
  } catch (e) {
    console.error("Failed to generate Smart Career Report:", e)
    process.exit(1)
     // first github push.
  }
})()
