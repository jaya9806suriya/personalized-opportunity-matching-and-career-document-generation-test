// Step 1: Analyze Student Profile using AI
// This step expects student profile fields as input (degree, year, CGPA, skills, interests, country)
// Uses OpenAI via Turbotic helper to analyze and summarize the profile for downstream steps

;(async () => {
  try {
    // Collect input fields (could be passed via environment or input form in UI)
    // For demonstration, try to read from env, but let the app prompt if missing
    const degree = process.env.DEGREE
    const year = process.env.YEAR
    const cgpa = process.env.CGPA
    const skills = process.env.SKILLS // Comma separated
    const interests = process.env.INTERESTS // Comma separated
    const country = process.env.COUNTRY

    if (!degree || !year || !cgpa || !skills || !interests || !country) {
      throw new Error("Missing one or more student profile fields: degree, year, CGPA, skills, interests, country. Please set them in environment/input.")
    }

    const profile = {
      degree,
      year,
      cgpa,
      skills: skills.split(",").map(s => s.trim()),
      interests: interests.split(",").map(i => i.trim()),
      country
    }

    // Analyze student profile with AI
    const analysisPrompt = `Analyze the following student profile. Identify the top strengths, possible career directions, and summary highlights. Format output as short paragraphs under 'Strengths', 'Career Pathways', and 'Noteworthy Highlights'.\nProfile: ${JSON.stringify(profile)}`
    const analysisResult = await TurboticOpenAI([{ role: "user", content: analysisPrompt }], { model: "gpt-4.1", temperature: 0 })

    setContext("studentProfile", profile)
    setContext("profileAnalysis", analysisResult.content) // <-- Synchronize context key with Step 2
    console.log("Set context: profileAnalysis")
    console.log("Profile analysis complete.")
  } catch (e) {
    console.error(e)
    process.exit(1)
  }
})()
